import React from 'react'
const Home = () => {
    return (
        <div class='home'>
            <h1 className='home-text'>Welcome To <span className='logo-c'>C</span>onqoll!</h1>
            <br />
            <h1 className='home-text1'>Hope you are having a good day <span className='logo-smiley'> : )</span></h1> 
            <br />   
        </div>
    )
}

export default Home