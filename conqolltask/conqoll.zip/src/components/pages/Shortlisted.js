import React from 'react'

const Shortlisted = () => {
    return (
        <div>
            <h1 className='short-text'>This is the <span className='short-text1'>SHORTLISTED</span>  Page</h1>     
        </div>
    )
}

export default Shortlisted